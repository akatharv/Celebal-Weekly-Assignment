# Memory-Augmented Chatbot (RAG + Knowledge Graph + Long-Term Memory)

A chatbot that combines three context sources — a static RAG knowledge
base, a knowledge graph, and long-term per-user memory — orchestrated by
a LangGraph agent that can also reach for live web search when needed.
Includes a custom evaluation framework to score response quality.

## Architecture

```
User message
     |
     v
[load_memory] ---- pulls durable facts about this user from SQLite
     |
     v
[agent] <--------------------------------------.
     |  (Claude decides: answer, or call a tool) |
     v                                           |
 tool call? --yes--> [execute_tools] ------------'
     |
     no
     v
[finalize] ---- writes turn to memory, returns answer
```

Tools available to the agent:
- `search_knowledge_base` — vector search (Chroma) over scraped + cleaned docs
- `query_knowledge_graph` — entity/relationship traversal (NetworkX)
- `web_search` — live web search (DuckDuckGo, no API key needed) for anything
  time-sensitive the static knowledge base won't have

## Project layout

```
config.py                  # all paths, model names, tunables in one place
ingestion/
  scraper.py                # fetches raw HTML -> data/raw/
  cleaner.py                 # HTML -> normalized text -> data/processed/
  chunker.py                  # token-aware chunking with overlap
rag/
  vector_store.py            # Chroma wrapper (embed + upsert + query)
  retriever.py                 # distance cutoff + prompt-ready formatting
knowledge_graph/
  kg_builder.py               # LLM-based entity/relation extraction -> graph
  kg_query.py                   # fuzzy entity match + bounded-hop traversal
memory/
  user_memory.py              # episodic turns + consolidated semantic facts
agent/
  tools.py                    # tool functions + Anthropic tool schemas
  graph.py                      # the LangGraph StateGraph itself
evaluation/
  metrics.py                  # faithfulness / relevance / precision / personalization
  eval_framework.py             # runs a test set, aggregates, saves report
main.py                     # interactive CLI
```

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then fill in ANTHROPIC_API_KEY
```

## Building the knowledge base (run once, in order)

```bash
python ingestion/scraper.py        # scrape seed URLs -> data/raw/
python ingestion/cleaner.py        # clean -> data/processed/
python rag/vector_store.py         # chunk + embed + index into Chroma
python knowledge_graph/kg_builder.py   # extract entities/relations -> graph
```

Edit the `seed_urls` list at the bottom of `ingestion/scraper.py` to point
at whatever domain you want the bot to be an expert in.

## Running the chatbot

```bash
python main.py
```

## Running evaluation

```bash
python evaluation/eval_framework.py
```

Edit `evaluation/test_set.json` (auto-created on first run) to add your
own gold questions. Each run saves a timestamped JSON report to
`storage/eval_results/`.

## Design decisions worth knowing for interviews

- **Why separate scraping/cleaning/chunking into three files instead of
  one pipeline function?** Single responsibility — each stage has a
  different failure mode (network errors vs. HTML noise vs. token limits)
  and you want to be able to re-run just one stage without redoing the
  others.
- **Why NetworkX instead of Neo4j?** No server to run, in-memory graph is
  fast enough for a project-scale knowledge base, and it's trivial to
  swap `kg_builder.py`'s persistence layer for a Neo4j driver later
  without touching `kg_query.py`'s interface.
- **Why two memory tables (episodic + semantic) instead of one?** Raw
  conversation history grows unbounded and isn't directly useful for
  personalization; periodically consolidating it into durable facts (via
  an LLM summarization pass) keeps the "what do I know about this user"
  context small and high-signal.
- **Why LangGraph instead of a plain while-loop calling the API?** The
  agent's control flow is genuinely conditional (0+ tool calls before
  answering), and LangGraph's conditional edges make that loop explicit
  and inspectable rather than buried in imperative logic.
- **Why an LLM-judge eval framework instead of exact-match metrics?**
  There's no single correct answer for open-ended questions, so
  faithfulness/relevance/precision are scored by having Claude itself act
  as a rubric-based judge — the same pattern used by RAGAS and most
  production RAG evals, just implemented from scratch so every score is
  explainable.

## Known limitations (be ready to discuss these)

- Entity extraction quality depends entirely on the extraction prompt —
  no evaluation of extraction accuracy itself, only downstream answer
  quality.
- Memory consolidation runs inline (blocking) rather than as a background
  job — fine for a demo, not for production latency.
- No re-ranking step after vector retrieval — top-k by cosine distance
  only. A cross-encoder re-ranker would be the natural next improvement.
- Single-process, no concurrency handling on the SQLite memory store.
