"""
Individual evaluation metrics. Each is LLM-judged against a rubric —
deliberately simple (single 1-5 score + justification) rather than
importing a black-box library, so you can explain exactly how every
number is produced.
"""
import json
from pathlib import Path

from anthropic import Anthropic

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import ANTHROPIC_API_KEY, UTILITY_MODEL

client = Anthropic(api_key=ANTHROPIC_API_KEY)


def _llm_judge(prompt: str) -> dict:
    response = client.messages.create(
        model=UTILITY_MODEL,
        max_tokens=400,
        messages=[{"role": "user", "content": prompt}],
    )
    raw = response.content[0].text.strip().replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"score": None, "justification": f"parse_error: {raw[:200]}"}


def score_faithfulness(answer: str, retrieved_context: str) -> dict:
    """Does the answer stay grounded in the retrieved context, or does it
    hallucinate claims not supported by it?"""
    prompt = f"""You are evaluating an AI assistant's answer for FAITHFULNESS to its
retrieved context — i.e. whether every factual claim in the answer is
supported by the context, with no fabrication.

Context provided to the assistant:
{retrieved_context}

Assistant's answer:
{answer}

Score 1-5 (1 = mostly fabricated, 5 = fully grounded, no unsupported claims).
Return ONLY JSON: {{"score": <int>, "justification": "<one sentence>"}}"""
    return _llm_judge(prompt)


def score_relevance(question: str, answer: str) -> dict:
    """Does the answer actually address what was asked?"""
    prompt = f"""You are evaluating an AI assistant's answer for RELEVANCE to the
question asked — does it actually address what was asked, without
padding or going off-topic?

Question: {question}
Answer: {answer}

Score 1-5 (1 = irrelevant, 5 = directly and completely relevant).
Return ONLY JSON: {{"score": <int>, "justification": "<one sentence>"}}"""
    return _llm_judge(prompt)


def score_context_precision(question: str, retrieved_context: str) -> dict:
    """Of the retrieved chunks, how many were actually useful for
    answering the question? (retrieval quality, not generation quality)"""
    prompt = f"""You are evaluating RETRIEVAL QUALITY: of the retrieved context below,
how much of it is actually relevant/useful for answering the question
(vs. noise that shouldn't have been retrieved)?

Question: {question}
Retrieved context: {retrieved_context}

Score 1-5 (1 = mostly irrelevant chunks, 5 = all chunks highly relevant).
Return ONLY JSON: {{"score": <int>, "justification": "<one sentence>"}}"""
    return _llm_judge(prompt)


def score_memory_personalization(question: str, answer: str, user_facts: str) -> dict:
    """When relevant user facts exist, does the answer make use of them
    appropriately (without forcing personalization where it isn't needed)?"""
    prompt = f"""You are evaluating whether an AI assistant appropriately used known
facts about the user when relevant, without shoehorning personalization
into places it doesn't belong.

Known facts about user: {user_facts}
Question: {question}
Answer: {answer}

Score 1-5 (1 = ignored clearly relevant facts OR forced irrelevant ones in,
5 = used relevant facts naturally, ignored irrelevant ones).
Return ONLY JSON: {{"score": <int>, "justification": "<one sentence>"}}"""
    return _llm_judge(prompt)
