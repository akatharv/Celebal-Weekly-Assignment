"""
Long-term user memory, split into two tables — a design choice worth
defending in interviews:

- `episodic_turns`: raw conversation history (what was said, when)
- `semantic_facts`: durable facts distilled FROM episodes (who the user is,
  their preferences, ongoing projects) — periodically consolidated by an
  LLM summarization pass so the fact table doesn't grow unbounded.

This mirrors how human memory researchers distinguish episodic vs semantic
memory, and it's the same pattern Claude's own memory system uses:
raw conversation -> periodic background summarization -> durable profile.
"""
import json
import sqlite3
import time
from pathlib import Path

from anthropic import Anthropic

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import (
    ANTHROPIC_API_KEY, UTILITY_MODEL, MEMORY_DB_PATH,
    SHORT_TERM_TURN_LIMIT, MEMORY_CONSOLIDATION_INTERVAL,
)

client = Anthropic(api_key=ANTHROPIC_API_KEY)

SCHEMA = """
CREATE TABLE IF NOT EXISTS episodic_turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS semantic_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    fact TEXT NOT NULL,
    category TEXT NOT NULL,
    created_at REAL NOT NULL,
    UNIQUE(user_id, fact)
);
"""

CONSOLIDATION_PROMPT = """Below is a batch of conversation turns between a user and an assistant.
Extract durable facts about the USER only (preferences, background, ongoing
projects, goals, constraints) — not facts about the world in general.

Return ONLY valid JSON (no markdown fences):
{{"facts": [{{"fact": "...", "category": "preference|background|goal|project|other"}}]}}

Only include facts that would still be useful to know in future, unrelated
conversations. Skip anything trivial or one-off.

Conversation:
{conversation}
"""


class UserMemory:
    def __init__(self, db_path: Path = MEMORY_DB_PATH):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        with self._connect() as conn:
            conn.executescript(SCHEMA)

    def _connect(self):
        return sqlite3.connect(self.db_path)

    # ---- Episodic (raw turns) -----------------------------------------
    def add_turn(self, user_id: str, role: str, content: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO episodic_turns (user_id, role, content, created_at) VALUES (?, ?, ?, ?)",
                (user_id, role, content, time.time()),
            )
        self._maybe_consolidate(user_id)

    def get_recent_turns(self, user_id: str, limit: int = SHORT_TERM_TURN_LIMIT) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT role, content FROM episodic_turns WHERE user_id = ? "
                "ORDER BY id DESC LIMIT ?",
                (user_id, limit),
            ).fetchall()
        return [{"role": r, "content": c} for r, c in reversed(rows)]

    # ---- Semantic (durable facts) --------------------------------------
    def add_fact(self, user_id: str, fact: str, category: str = "other") -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO semantic_facts (user_id, fact, category, created_at) "
                "VALUES (?, ?, ?, ?)",
                (user_id, fact, category, time.time()),
            )

    def get_facts(self, user_id: str) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT fact, category FROM semantic_facts WHERE user_id = ? ORDER BY id",
                (user_id,),
            ).fetchall()
        return [{"fact": f, "category": c} for f, c in rows]

    def get_facts_as_context(self, user_id: str) -> str:
        facts = self.get_facts(user_id)
        if not facts:
            return "No prior information about this user."
        return "What you know about this user:\n" + "\n".join(f"- [{f['category']}] {f['fact']}" for f in facts)

    # ---- Consolidation (episodic -> semantic) ---------------------------
    def _maybe_consolidate(self, user_id: str) -> None:
        with self._connect() as conn:
            count = conn.execute(
                "SELECT COUNT(*) FROM episodic_turns WHERE user_id = ?", (user_id,)
            ).fetchone()[0]
        if count > 0 and count % MEMORY_CONSOLIDATION_INTERVAL == 0:
            self.consolidate(user_id)

    def consolidate(self, user_id: str, turn_window: int = MEMORY_CONSOLIDATION_INTERVAL) -> None:
        """Runs an LLM pass over recent turns to extract durable facts.
        This is what would run as a background job in production —
        here it's called inline for simplicity."""
        turns = self.get_recent_turns(user_id, limit=turn_window)
        if not turns:
            return
        conversation = "\n".join(f"{t['role']}: {t['content']}" for t in turns)

        response = client.messages.create(
            model=UTILITY_MODEL,
            max_tokens=800,
            messages=[{"role": "user", "content": CONSOLIDATION_PROMPT.format(conversation=conversation)}],
        )
        raw = response.content[0].text.strip().replace("```json", "").replace("```", "").strip()
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            print("Warning: memory consolidation failed to parse output")
            return

        for item in parsed.get("facts", []):
            self.add_fact(user_id, item["fact"], item.get("category", "other"))
        print(f"Consolidated {len(parsed.get('facts', []))} new facts for user {user_id}")


if __name__ == "__main__":
    mem = UserMemory()
    mem.add_turn("demo_user", "user", "I'm a final-year CS student prepping for placements.")
    mem.add_turn("demo_user", "assistant", "Got it — want help with DSA or system design?")
    print(mem.get_facts_as_context("demo_user"))
