"""
LangGraph orchestration layer.

Flow:
  load_memory -> agent (Claude decides: answer directly OR call a tool)
      -> [if tool call] execute_tools -> back to agent
      -> [if no tool call] save_memory -> END

Interview talking point: LangGraph is used here specifically because the
control flow isn't linear — the model may need 0, 1, or several tool
calls before it has enough context to answer, and LangGraph's conditional
edges model that loop cleanly (vs. hand-rolling a while-loop, which is
what most people did before graph-based agent frameworks existed).
"""
from pathlib import Path
from typing import TypedDict, Annotated
import operator

from anthropic import Anthropic
from langgraph.graph import StateGraph, END

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import ANTHROPIC_API_KEY, CHAT_MODEL, MAX_TOKENS, MAX_AGENT_STEPS
from memory.user_memory import UserMemory
from agent.tools import TOOL_REGISTRY, TOOL_SCHEMAS

client = Anthropic(api_key=ANTHROPIC_API_KEY)
memory_store = UserMemory()

SYSTEM_PROMPT = """You are a helpful, memory-aware assistant. You have access to:
- a static knowledge base (search_knowledge_base)
- a knowledge graph of entities/relationships (query_knowledge_graph)
- live web search (web_search) for anything current or time-sensitive

Use tools when you need information you don't already have in the
conversation or in the "known facts about this user" context below.
Don't call a tool if the answer is already available to you.
Be concise and cite which source (knowledge base / knowledge graph / web)
a fact came from when relevant.

{user_context}
"""


class AgentState(TypedDict):
    user_id: str
    messages: Annotated[list, operator.add]
    step_count: int
    final_response: str


def load_memory_node(state: AgentState) -> AgentState:
    """Injects long-term memory facts as a system-level context string.
    We stash it on the state so the agent_node can build the system prompt."""
    facts_context = memory_store.get_facts_as_context(state["user_id"])
    state["_user_context"] = facts_context  # type: ignore[typeddict-item]
    return state


def agent_node(state: AgentState) -> AgentState:
    user_context = state.get("_user_context", "No prior information about this user.")  # type: ignore
    system = SYSTEM_PROMPT.format(user_context=user_context)

    response = client.messages.create(
        model=CHAT_MODEL,
        max_tokens=MAX_TOKENS,
        system=system,
        tools=TOOL_SCHEMAS,
        messages=state["messages"],
    )

    # Convert Claude's response content blocks into a plain message dict
    assistant_message = {"role": "assistant", "content": response.content}
    return {
        "messages": [assistant_message],
        "step_count": state["step_count"] + 1,
        "_last_stop_reason": response.stop_reason,  # type: ignore
    }


def should_continue(state: AgentState) -> str:
    last_message = state["messages"][-1]
    has_tool_use = any(getattr(block, "type", None) == "tool_use" for block in last_message["content"])

    if has_tool_use and state["step_count"] < MAX_AGENT_STEPS:
        return "execute_tools"
    return "finalize"


def execute_tools_node(state: AgentState) -> AgentState:
    last_message = state["messages"][-1]
    tool_results = []

    for block in last_message["content"]:
        if getattr(block, "type", None) == "tool_use":
            tool_fn = TOOL_REGISTRY.get(block.name)
            if tool_fn is None:
                result_text = f"Unknown tool: {block.name}"
            else:
                try:
                    result_text = tool_fn(**block.input)
                except Exception as e:
                    result_text = f"Tool execution failed: {e}"

            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": result_text,
            })

    return {"messages": [{"role": "user", "content": tool_results}]}


def finalize_node(state: AgentState) -> AgentState:
    last_message = state["messages"][-1]
    text_parts = [b.text for b in last_message["content"] if getattr(b, "type", None) == "text"]
    final_text = "\n".join(text_parts) if text_parts else ""

    # Persist the turn to long-term memory
    user_turn = next((m for m in reversed(state["messages"]) if m["role"] == "user"
                       and isinstance(m["content"], str)), None)
    if user_turn:
        memory_store.add_turn(state["user_id"], "user", user_turn["content"])
    memory_store.add_turn(state["user_id"], "assistant", final_text)

    return {"final_response": final_text}


def build_agent_graph():
    graph = StateGraph(AgentState)

    graph.add_node("load_memory", load_memory_node)
    graph.add_node("agent", agent_node)
    graph.add_node("execute_tools", execute_tools_node)
    graph.add_node("finalize", finalize_node)

    graph.set_entry_point("load_memory")
    graph.add_edge("load_memory", "agent")
    graph.add_conditional_edges("agent", should_continue, {
        "execute_tools": "execute_tools",
        "finalize": "finalize",
    })
    graph.add_edge("execute_tools", "agent")
    graph.add_edge("finalize", END)

    return graph.compile()


def chat(user_id: str, user_message: str) -> str:
    app = build_agent_graph()
    initial_state: AgentState = {
        "user_id": user_id,
        "messages": [{"role": "user", "content": user_message}],
        "step_count": 0,
        "final_response": "",
    }
    result = app.invoke(initial_state)
    return result["final_response"]


if __name__ == "__main__":
    reply = chat("demo_user", "What is retrieval-augmented generation and how does it relate to knowledge graphs?")
    print("\nASSISTANT:", reply)
