"""
Builds a knowledge graph from cleaned documents using Claude for
entity/relationship extraction, stored with NetworkX.

Interview talking point: this is a lightweight alternative to a full
NER + relation-extraction pipeline (spaCy + REBEL, etc). Using the LLM
itself as the extractor is faster to prototype and easier to defend
("I structured the extraction prompt with schema constraints"), at the
cost of being slower/costlier at scale than a dedicated pipeline.
"""
import json
import pickle
from pathlib import Path

import networkx as nx
from anthropic import Anthropic

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import ANTHROPIC_API_KEY, UTILITY_MODEL, PROCESSED_DATA_DIR, KG_PERSIST_PATH

client = Anthropic(api_key=ANTHROPIC_API_KEY)

EXTRACTION_PROMPT = """Extract entities and relationships from the text below.
Return ONLY valid JSON (no markdown fences, no preamble) matching this schema:

{{
  "entities": [{{"name": "...", "type": "PERSON|ORG|CONCEPT|TECHNOLOGY|LOCATION|OTHER"}}],
  "relations": [{{"source": "...", "relation": "...", "target": "..."}}]
}}

Rules:
- Only extract relations where both entities are also listed in "entities".
- Keep entity names short and canonical (e.g. "RAG" not "retrieval augmented generation systems").
- Keep relation labels short, lowercase, verb-like (e.g. "uses", "developed_by", "part_of").
- Extract at most 15 entities and 20 relations — prioritize the most important ones.

Text:
{text}
"""


def extract_entities_and_relations(text: str) -> dict:
    response = client.messages.create(
        model=UTILITY_MODEL,
        max_tokens=1500,
        messages=[{"role": "user", "content": EXTRACTION_PROMPT.format(text=text[:6000])}],
    )
    raw = response.content[0].text.strip()
    raw = raw.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        print("Warning: failed to parse extraction output, skipping doc")
        return {"entities": [], "relations": []}


def build_graph_from_processed_docs() -> nx.MultiDiGraph:
    graph = nx.MultiDiGraph()

    for path in PROCESSED_DATA_DIR.glob("*.json"):
        doc = json.loads(path.read_text())
        print(f"Extracting entities/relations from: {doc['title']}")
        extraction = extract_entities_and_relations(doc["text"])

        for ent in extraction.get("entities", []):
            graph.add_node(
                ent["name"],
                type=ent.get("type", "OTHER"),
                source_doc=doc["doc_id"],
                source_title=doc["title"],
            )

        for rel in extraction.get("relations", []):
            if rel["source"] in graph and rel["target"] in graph:
                graph.add_edge(
                    rel["source"], rel["target"],
                    relation=rel["relation"],
                    source_doc=doc["doc_id"],
                )

    print(f"Graph built: {graph.number_of_nodes()} nodes, {graph.number_of_edges()} edges")
    return graph


def save_graph(graph: nx.MultiDiGraph, path: Path = KG_PERSIST_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(graph, f)
    print(f"Saved graph to {path}")


def load_graph(path: Path = KG_PERSIST_PATH) -> nx.MultiDiGraph:
    with open(path, "rb") as f:
        return pickle.load(f)


if __name__ == "__main__":
    g = build_graph_from_processed_docs()
    save_graph(g)
