"""
Splits cleaned documents into overlapping chunks for embedding.

Interview talking point: chunking is token-aware (via tiktoken) rather than
naive character-splitting, and overlap exists so a fact split across a
chunk boundary is still retrievable from at least one chunk.
"""
import json
from dataclasses import dataclass, asdict
from pathlib import Path

import tiktoken

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import PROCESSED_DATA_DIR, CHUNK_SIZE, CHUNK_OVERLAP

_encoder = tiktoken.get_encoding("cl100k_base")


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    source_url: str
    source_title: str
    text: str
    chunk_index: int


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    tokens = _encoder.encode(text)
    chunks = []
    start = 0
    while start < len(tokens):
        end = min(start + chunk_size, len(tokens))
        chunk_tokens = tokens[start:end]
        chunks.append(_encoder.decode(chunk_tokens))
        if end == len(tokens):
            break
        start = end - overlap  # step forward, keeping overlap
    return chunks


def chunk_all_processed_documents() -> list[Chunk]:
    all_chunks = []
    for path in PROCESSED_DATA_DIR.glob("*.json"):
        doc = json.loads(path.read_text())
        text_chunks = chunk_text(doc["text"])
        for i, t in enumerate(text_chunks):
            all_chunks.append(Chunk(
                chunk_id=f"{doc['doc_id']}_{i}",
                doc_id=doc["doc_id"],
                source_url=doc["url"],
                source_title=doc["title"],
                text=t,
                chunk_index=i,
            ))
        print(f"chunked {doc['url']} -> {len(text_chunks)} chunks")
    return all_chunks


if __name__ == "__main__":
    chunks = chunk_all_processed_documents()
    print(f"\nTotal chunks: {len(chunks)}")
