"""
Evaluation harness: runs a gold test set through the agent, scores each
response on multiple metrics, and writes a report.

Interview talking point: this closes the loop on the whole project — it's
what lets you say "I measured retrieval precision at X and faithfulness
at Y" instead of just "it seemed to work when I tried it".
"""
import json
import time
from pathlib import Path

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import EVAL_RESULTS_DIR
from rag.retriever import Retriever
from memory.user_memory import UserMemory
from agent.graph import chat
from evaluation.metrics import (
    score_faithfulness, score_relevance,
    score_context_precision, score_memory_personalization,
)

TEST_SET_PATH = Path(__file__).parent / "test_set.json"


def load_test_set() -> list[dict]:
    """Each item: {"question": str, "user_id": str}"""
    if not TEST_SET_PATH.exists():
        default_set = [
            {"question": "What is retrieval-augmented generation?", "user_id": "eval_user"},
            {"question": "How does a knowledge graph differ from a vector database?", "user_id": "eval_user"},
        ]
        TEST_SET_PATH.write_text(json.dumps(default_set, indent=2))
        return default_set
    return json.loads(TEST_SET_PATH.read_text())


def run_evaluation() -> dict:
    test_cases = load_test_set()
    retriever = Retriever()
    memory_store = UserMemory()

    results = []
    for case in test_cases:
        question, user_id = case["question"], case["user_id"]
        print(f"\nEvaluating: {question}")

        start = time.time()
        answer = chat(user_id, question)
        latency = time.time() - start

        context = retriever.retrieve_as_context(question)
        user_facts = memory_store.get_facts_as_context(user_id)

        faithfulness = score_faithfulness(answer, context)
        relevance = score_relevance(question, answer)
        precision = score_context_precision(question, context)
        personalization = score_memory_personalization(question, answer, user_facts)

        results.append({
            "question": question,
            "answer": answer,
            "latency_seconds": round(latency, 2),
            "faithfulness": faithfulness,
            "relevance": relevance,
            "context_precision": precision,
            "memory_personalization": personalization,
        })

    report = _aggregate(results)
    _save_report(report)
    return report


def _aggregate(results: list[dict]) -> dict:
    def avg(key):
        scores = [r[key]["score"] for r in results if r[key].get("score") is not None]
        return round(sum(scores) / len(scores), 2) if scores else None

    return {
        "num_cases": len(results),
        "avg_faithfulness": avg("faithfulness"),
        "avg_relevance": avg("relevance"),
        "avg_context_precision": avg("context_precision"),
        "avg_memory_personalization": avg("memory_personalization"),
        "avg_latency_seconds": round(sum(r["latency_seconds"] for r in results) / len(results), 2) if results else None,
        "detailed_results": results,
    }


def _save_report(report: dict) -> None:
    out_path = EVAL_RESULTS_DIR / f"eval_report_{int(time.time())}.json"
    out_path.write_text(json.dumps(report, indent=2))
    print(f"\nSaved eval report to {out_path}")
    print(f"\nSummary: faithfulness={report['avg_faithfulness']} "
          f"relevance={report['avg_relevance']} "
          f"context_precision={report['avg_context_precision']} "
          f"personalization={report['avg_memory_personalization']} "
          f"avg_latency={report['avg_latency_seconds']}s")


if __name__ == "__main__":
    run_evaluation()
