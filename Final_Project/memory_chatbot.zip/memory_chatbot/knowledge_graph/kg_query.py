"""
Query interface for the knowledge graph: entity lookup + bounded-hop
traversal, formatted as a context block the agent can inject into prompts.
"""
from pathlib import Path
from difflib import get_close_matches

import networkx as nx

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import KG_MAX_HOPS, KG_PERSIST_PATH
from knowledge_graph.kg_builder import load_graph


class KnowledgeGraphQuery:
    def __init__(self, graph: nx.MultiDiGraph | None = None):
        if graph is not None:
            self.graph = graph
        else:
            try:
                self.graph = load_graph(KG_PERSIST_PATH)
            except FileNotFoundError:
                self.graph = nx.MultiDiGraph()

    def find_matching_entities(self, query: str, cutoff: float = 0.6) -> list[str]:
        """Fuzzy-match query terms against node names (cheap alternative to
        embedding-based entity linking — fine for a graph of this size)."""
        nodes = list(self.graph.nodes)
        words = query.replace("?", "").split()
        matches = set()
        for w in words:
            matches.update(get_close_matches(w, nodes, n=3, cutoff=cutoff))
        # Also try the full query string against node names
        matches.update(get_close_matches(query, nodes, n=3, cutoff=cutoff))
        return list(matches)

    def get_subgraph_facts(self, entity: str, max_hops: int = KG_MAX_HOPS) -> list[str]:
        """Returns human-readable facts within max_hops of the entity."""
        if entity not in self.graph:
            return []

        facts = []
        visited_edges = set()
        frontier = {entity}
        for _ in range(max_hops):
            next_frontier = set()
            for node in frontier:
                for _, target, data in self.graph.out_edges(node, data=True):
                    key = (node, data.get("relation"), target)
                    if key not in visited_edges:
                        visited_edges.add(key)
                        facts.append(f"{node} --{data.get('relation')}--> {target}")
                        next_frontier.add(target)
                for source, _, data in self.graph.in_edges(node, data=True):
                    key = (source, data.get("relation"), node)
                    if key not in visited_edges:
                        visited_edges.add(key)
                        facts.append(f"{source} --{data.get('relation')}--> {node}")
                        next_frontier.add(source)
            frontier = next_frontier
        return facts

    def query_as_context(self, query: str) -> str:
        entities = self.find_matching_entities(query)
        if not entities:
            return "No relevant entities found in the knowledge graph."

        all_facts = []
        for ent in entities:
            all_facts.extend(self.get_subgraph_facts(ent))

        if not all_facts:
            return "No relevant relationships found in the knowledge graph."

        # de-dupe while preserving order
        seen = set()
        unique_facts = [f for f in all_facts if not (f in seen or seen.add(f))]
        return "Knowledge graph facts:\n" + "\n".join(f"- {f}" for f in unique_facts[:20])


if __name__ == "__main__":
    kgq = KnowledgeGraphQuery()
    print(kgq.query_as_context("What is the relationship between RAG and knowledge graphs?"))
