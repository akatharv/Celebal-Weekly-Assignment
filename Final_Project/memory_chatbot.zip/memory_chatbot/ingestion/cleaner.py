"""
Cleans raw scraped HTML into normalized plain text ready for chunking.

Interview talking point: cleaning is deliberately conservative — we strip
nav/script/style/footer noise but keep paragraph structure, since RAG
retrieval quality depends heavily on chunk coherence, not just "text density".
"""
import json
import re
from pathlib import Path

from bs4 import BeautifulSoup

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import RAW_DATA_DIR, PROCESSED_DATA_DIR

NOISE_TAGS = ["script", "style", "nav", "footer", "header", "aside", "form", "noscript"]


def clean_html(raw_html: str) -> str:
    soup = BeautifulSoup(raw_html, "html.parser")

    for tag in soup(NOISE_TAGS):
        tag.decompose()

    # Prefer <article> or <main> if present — usually the actual content
    main = soup.find("article") or soup.find("main") or soup

    text = main.get_text(separator="\n")

    # Normalize whitespace: collapse 3+ newlines, strip trailing spaces
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
    lines = [line.strip() for line in text.split("\n")]
    text = "\n".join(line for line in lines if line)

    return text.strip()


def clean_all_raw_documents() -> list[dict]:
    """Reads every JSON file in data/raw/, cleans it, writes to
    data/processed/<doc_id>.json with {doc_id, url, title, text}."""
    cleaned_docs = []
    for raw_path in RAW_DATA_DIR.glob("*.json"):
        raw = json.loads(raw_path.read_text())
        cleaned_text = clean_html(raw["raw_html"])

        if len(cleaned_text) < 200:
            print(f"skip (too short after cleaning): {raw['url']}")
            continue

        cleaned = {
            "doc_id": raw["doc_id"],
            "url": raw["url"],
            "title": raw["title"],
            "text": cleaned_text,
        }
        out_path = PROCESSED_DATA_DIR / f"{raw['doc_id']}.json"
        out_path.write_text(json.dumps(cleaned, ensure_ascii=False, indent=2))
        cleaned_docs.append(cleaned)
        print(f"cleaned: {raw['url']} ({len(cleaned_text)} chars)")

    return cleaned_docs


if __name__ == "__main__":
    clean_all_raw_documents()
