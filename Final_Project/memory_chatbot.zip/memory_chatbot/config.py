"""
Central configuration for the memory-augmented chatbot.
All paths, model names, and tunable parameters live here so the
rest of the codebase never hardcodes them.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ---- Paths -----------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
CHROMA_PERSIST_DIR = BASE_DIR / "storage" / "chroma"
KG_PERSIST_PATH = BASE_DIR / "storage" / "knowledge_graph.gpickle"
MEMORY_DB_PATH = BASE_DIR / "storage" / "memory.db"
EVAL_RESULTS_DIR = BASE_DIR / "storage" / "eval_results"

for p in [RAW_DATA_DIR, PROCESSED_DATA_DIR, CHROMA_PERSIST_DIR.parent, EVAL_RESULTS_DIR]:
    p.mkdir(parents=True, exist_ok=True)

# ---- API keys ----------------------------------------------------------
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

# ---- Model config --------------------------------------------------------
# Model used for generation (chat responses)
CHAT_MODEL = "claude-sonnet-4-6"
# Cheaper/faster model for auxiliary tasks: entity extraction, memory
# summarization, eval judging. Swap to CHAT_MODEL if you don't have
# access to a smaller model.
UTILITY_MODEL = "claude-sonnet-4-6"
MAX_TOKENS = 1024

# Embedding model (local, via sentence-transformers — free, no API calls)
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# ---- RAG config ------------------------------------------------------
CHUNK_SIZE = 500          # tokens per chunk
CHUNK_OVERLAP = 75        # overlap between consecutive chunks
TOP_K_RETRIEVAL = 5       # chunks pulled from vector store per query
RAG_COLLECTION_NAME = "knowledge_base"

# ---- Knowledge graph config -------------------------------------------
KG_MAX_HOPS = 2            # how far to traverse from a matched entity

# ---- Memory config -----------------------------------------------------
# How many recent turns to keep verbatim before summarizing older ones
SHORT_TERM_TURN_LIMIT = 8
# Long-term memory facts are re-summarized after this many new turns
MEMORY_CONSOLIDATION_INTERVAL = 10

# ---- Agent config ------------------------------------------------------
MAX_AGENT_STEPS = 6        # safety limit on LangGraph tool-calling loops
