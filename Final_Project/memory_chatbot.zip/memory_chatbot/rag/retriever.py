"""
Retriever sits between the vector store and the agent: it applies a
relevance-distance cutoff and formats hits into a citation-ready context
block. Keeping this separate from vector_store.py means you can swap in
re-ranking (e.g. cross-encoder) later without touching storage code.
"""
from pathlib import Path

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import TOP_K_RETRIEVAL
from rag.vector_store import VectorStore

# Cosine distance cutoff — hits farther than this are considered irrelevant.
# Tune this against your own eval set (see evaluation/).
MAX_DISTANCE = 0.8


class Retriever:
    def __init__(self, store: VectorStore | None = None):
        self.store = store or VectorStore()

    def retrieve(self, query: str, top_k: int = TOP_K_RETRIEVAL) -> list[dict]:
        hits = self.store.query(query, top_k=top_k)
        return [h for h in hits if h["distance"] <= MAX_DISTANCE]

    def retrieve_as_context(self, query: str, top_k: int = TOP_K_RETRIEVAL) -> str:
        """Returns a formatted string block ready to inject into a prompt,
        with numbered sources so the model can cite them."""
        hits = self.retrieve(query, top_k=top_k)
        if not hits:
            return "No relevant documents found in the knowledge base."

        blocks = []
        for i, h in enumerate(hits, 1):
            title = h["metadata"].get("source_title", "unknown source")
            url = h["metadata"].get("source_url", "")
            blocks.append(f"[{i}] Source: {title} ({url})\n{h['text']}")
        return "\n\n".join(blocks)


if __name__ == "__main__":
    retriever = Retriever()
    print(retriever.retrieve_as_context("What is retrieval-augmented generation?"))
