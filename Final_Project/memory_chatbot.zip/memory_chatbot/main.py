"""
CLI entry point. Run `python main.py` for an interactive chat session
against the memory-augmented agent.
"""
from agent.graph import chat


def run_cli():
    print("Memory-Augmented Chatbot — type 'exit' to quit\n")
    user_id = input("Enter a user id (any string, used for memory): ").strip() or "default_user"

    while True:
        user_input = input("\nYou: ").strip()
        if user_input.lower() in {"exit", "quit"}:
            break
        if not user_input:
            continue

        response = chat(user_id, user_input)
        print(f"\nAssistant: {response}")


if __name__ == "__main__":
    run_cli()
