"""
Thin wrapper around ChromaDB so the rest of the app never touches the
Chroma API directly — makes it a one-file swap if you later move to
Pinecone/Weaviate for the "cloud" version of this project.
"""
from pathlib import Path

import chromadb
from chromadb.utils import embedding_functions

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import CHROMA_PERSIST_DIR, EMBEDDING_MODEL, RAG_COLLECTION_NAME
from ingestion.chunker import Chunk


class VectorStore:
    def __init__(self, collection_name: str = RAG_COLLECTION_NAME):
        self.client = chromadb.PersistentClient(path=str(CHROMA_PERSIST_DIR))
        self.embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name=EMBEDDING_MODEL
        )
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=self.embedding_fn,
            metadata={"hnsw:space": "cosine"},
        )

    def add_chunks(self, chunks: list[Chunk], batch_size: int = 64) -> None:
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]
            self.collection.upsert(
                ids=[c.chunk_id for c in batch],
                documents=[c.text for c in batch],
                metadatas=[{
                    "doc_id": c.doc_id,
                    "source_url": c.source_url,
                    "source_title": c.source_title,
                    "chunk_index": c.chunk_index,
                } for c in batch],
            )
        print(f"Indexed {len(chunks)} chunks into '{self.collection.name}'")

    def query(self, query_text: str, top_k: int = 5) -> list[dict]:
        results = self.collection.query(query_texts=[query_text], n_results=top_k)
        hits = []
        for i in range(len(results["ids"][0])):
            hits.append({
                "chunk_id": results["ids"][0][i],
                "text": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
                "distance": results["distances"][0][i],
            })
        return hits

    def count(self) -> int:
        return self.collection.count()


if __name__ == "__main__":
    from ingestion.chunker import chunk_all_processed_documents
    store = VectorStore()
    chunks = chunk_all_processed_documents()
    if chunks:
        store.add_chunks(chunks)
    print("Total vectors in store:", store.count())
