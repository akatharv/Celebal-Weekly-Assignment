"""
Lightweight web scraper for building the static knowledge base.

Design notes for your interview defense:
- We keep scraping and cleaning as SEPARATE stages (single responsibility).
  Scraper only fetches raw HTML/text and saves it to disk with metadata.
  Cleaner (cleaner.py) is responsible for turning that into normalized text.
- Every scraped doc gets a stable ID (hash of URL) so re-runs are idempotent
  and you can trace any chunk in the vector store back to its source.
"""
import hashlib
import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path

import requests
from bs4 import BeautifulSoup

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config import RAW_DATA_DIR


@dataclass
class ScrapedDocument:
    doc_id: str
    url: str
    title: str
    raw_html: str
    fetched_at: float


def _doc_id_for_url(url: str) -> str:
    return hashlib.sha256(url.encode("utf-8")).hexdigest()[:16]


def scrape_url(url: str, timeout: int = 15) -> ScrapedDocument:
    """Fetch a single URL and return a raw ScrapedDocument (unparsed HTML kept
    intact so the cleaner can decide what to keep)."""
    headers = {"User-Agent": "Mozilla/5.0 (compatible; MemoryBot/1.0; +educational-project)"}
    resp = requests.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()

    soup = BeautifulSoup(resp.text, "html.parser")
    title = soup.title.string.strip() if soup.title and soup.title.string else url

    return ScrapedDocument(
        doc_id=_doc_id_for_url(url),
        url=url,
        title=title,
        raw_html=resp.text,
        fetched_at=time.time(),
    )


def scrape_urls(urls: list[str], delay_seconds: float = 1.0) -> list[ScrapedDocument]:
    """Scrape a list of URLs politely (rate-limited) and persist each to
    data/raw/<doc_id>.json. Returns the list of documents scraped."""
    documents = []
    for i, url in enumerate(urls):
        try:
            doc = scrape_url(url)
            out_path = RAW_DATA_DIR / f"{doc.doc_id}.json"
            out_path.write_text(json.dumps(asdict(doc), ensure_ascii=False, indent=2))
            documents.append(doc)
            print(f"[{i+1}/{len(urls)}] scraped: {url}")
        except Exception as e:
            print(f"[{i+1}/{len(urls)}] FAILED: {url} -> {e}")
        time.sleep(delay_seconds)
    return documents


if __name__ == "__main__":
    # Example usage — replace with your own seed URLs.
    seed_urls = [
        "https://en.wikipedia.org/wiki/Retrieval-augmented_generation",
        "https://en.wikipedia.org/wiki/Knowledge_graph",
    ]
    scrape_urls(seed_urls)
