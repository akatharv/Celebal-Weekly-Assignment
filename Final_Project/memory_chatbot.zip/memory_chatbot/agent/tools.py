"""
Tool functions exposed to the LangGraph agent. Each tool is a plain
function with a docstring the model uses to decide when to call it —
kept dependency-light (duckduckgo-search needs no API key, good for a
student project with no budget for a paid search API).
"""
from pathlib import Path

from duckduckgo_search import DDGS

import sys
sys.path.append(str(Path(__file__).resolve().parent.parent))
from rag.retriever import Retriever
from knowledge_graph.kg_query import KnowledgeGraphQuery

_retriever = Retriever()
_kg = KnowledgeGraphQuery()


def search_knowledge_base(query: str) -> str:
    """Search the static knowledge base (vector store) for information
    relevant to the query. Use this first for any factual question —
    it's faster and more reliable than live web search."""
    return _retriever.retrieve_as_context(query)


def query_knowledge_graph(query: str) -> str:
    """Search the knowledge graph for entities and their relationships.
    Use this when the question is about how concepts/entities relate to
    each other, not just isolated facts."""
    return _kg.query_as_context(query)


def web_search(query: str, max_results: int = 5) -> str:
    """Search the live web for current/real-time information not covered
    by the static knowledge base — e.g. recent events, prices, news."""
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
        if not results:
            return "No web results found."
        blocks = [f"[{i+1}] {r['title']}\n{r['body']}\n{r['href']}"
                  for i, r in enumerate(results)]
        return "\n\n".join(blocks)
    except Exception as e:
        return f"Web search failed: {e}"


# Registry the agent graph will use to dispatch tool calls by name
TOOL_REGISTRY = {
    "search_knowledge_base": search_knowledge_base,
    "query_knowledge_graph": query_knowledge_graph,
    "web_search": web_search,
}

# Anthropic tool-use schema for each tool
TOOL_SCHEMAS = [
    {
        "name": "search_knowledge_base",
        "description": search_knowledge_base.__doc__.strip(),
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string", "description": "The search query"}},
            "required": ["query"],
        },
    },
    {
        "name": "query_knowledge_graph",
        "description": query_knowledge_graph.__doc__.strip(),
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string", "description": "The search query"}},
            "required": ["query"],
        },
    },
    {
        "name": "web_search",
        "description": web_search.__doc__.strip(),
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string", "description": "The search query"}},
            "required": ["query"],
        },
    },
]
